package uniandes.dpoo.taller2.modelo;

import java.util.ArrayList;

public class Combo implements Producto {
	
	private double descuento;
	private String nombreCombo;;
	private int precio;
	static ArrayList<Producto> itemsCombo;
	private String Agregados;

	public Combo(String nombre, double descuento, int producto1, int producto2, int producto3)
	{
		this.descuento= descuento;
		this.nombreCombo= nombre;
		precio= (int) ((producto1 + producto2+ producto3)- ((producto1 + producto2+ producto3)*(this.descuento/100)));
	}
	public void agregaritemACombo(ProductoMenu itemCombo) {
		Agregados+=itemCombo.getNombre()+" ,";
		precio= precio+itemCombo.getPrecio();
	}
	public int getPrecio() {
		return precio;
	}
	
	public String generarTextoFactura() {
		String combo="";
		combo+="+ "+ nombreCombo+" ----- $"+Integer.toString(precio)+"\n";
		if (Agregados != "") {
			combo+="(Con adicion de "+Agregados+")\n";	
		}
		return combo;
		
		
	}
	public String getNombre() {
		
	    return nombreCombo;
	}
}	
