package uniandes.dpoo.taller2.modelo;

public interface Producto {
	
	public abstract String getNombre();
	
	public abstract int getPrecio();
	
	public abstract String generarTextoFactura();

}
