package uniandes.dpoo.taller2.modelo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class Restaurante {
	
	static Map<String, Ingrediente> ingredientes = new HashMap<>();
	
	static Map<String, Ingrediente> noIngredientes = new HashMap<>();
	
	static ArrayList<Ingrediente> list_ingredientes= new ArrayList<>();
	
	static Map<String, ProductoMenu> menu = new HashMap<>();
	
	static Map<String, ProductoMenu> noProductoMenu = new HashMap<>();
	
	static ArrayList<ProductoMenu> list_productosMenuBase= new ArrayList<>();
	
	static Map<String, Combo> combos = new HashMap<>();
	
	static Map<String, Combo> noCombos = new HashMap<>();
	
	static ArrayList<Combo> list_combos= new ArrayList<>();
	
	private static Pedido pedido_en_curso;
	
	static Map<String, String> Pedidos=new HashMap<>();
	
	public Restaurante()
	{
		
	}
	
	public static void iniciarPedido(String nombreCliente, String direccionCliente)
	{
	 pedido_en_curso= new Pedido(nombreCliente, direccionCliente);
	}
	
	
	public static void agregarProducto(int producto)
	{
	if (producto <= 22){
	 pedido_en_curso.agregarProducto(noProductoMenu.get(Integer.toString(producto)));
	}
	 
	else if (producto>=23 && producto<=26){
		 pedido_en_curso.agregarProducto(noCombos.get(Integer.toString(producto)));
		}
	
	}
	
	public static void agregarIngredientes(int productobase,int nuevoItem) {
		pedido_en_curso.agregarIngrediente(noProductoMenu.get(Integer.toString(productobase)),noIngredientes.get(Integer.toString(nuevoItem)) );
	}
	
	public static void eliminarIngredientes(int productobase,int nuevoItem) {
		pedido_en_curso.eliminarIngrediente(noProductoMenu.get(Integer.toString(productobase)), noIngredientes.get(Integer.toString(nuevoItem)));
	}
	
	public static void agregarProductoCombo(int combobase, int producto) {
		pedido_en_curso.agregarProductoCombo(noCombos.get(Integer.toString(combobase)), noProductoMenu.get(Integer.toString(producto)));
		
	}
	
	
	
	
	public static String consultarPedidoPorId(String IdPedido) {
		String facturaped= Pedidos.get(IdPedido);
		return facturaped;
	}
	
	
	
	
	public static void cerrarYGuardarPedido() throws IOException
	{
	Pedidos.put(Integer.toString(pedido_en_curso.getIdPedido()), pedido_en_curso.generarTextoFactura());
	String ruta = "C:/Users/ACER/eclipse-workspace/Taller2_Hamburguesas/Pedidos/"+Integer.toString(pedido_en_curso.getIdPedido())+".txt";
	FileWriter file= new FileWriter(ruta);
	pedido_en_curso.guardarFactura(file);
	}
	
	public static Pedido getPedidoEnCurso()
	{
		return pedido_en_curso;
	}
	
	public static ArrayList <ProductoMenu> getMenuBase()
	{
		return list_productosMenuBase;
	}
	
	public static ArrayList <Ingrediente> getIngredientes()
	{
		return list_ingredientes;

	}
	
	public static ArrayList <Combo> getCombos()
	{
		return list_combos;

	}
	
	public static void cargarInformacionRestaurante(File archivoIngredientes, File archivoMenu, File archivoCombos) throws IOException
	{
		cargarIngredientes(archivoIngredientes);
		cargarMenu(archivoMenu);
		cargarCombos(archivoCombos);
		
	}
	
	private static void cargarIngredientes(File archivoIngredientes) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(archivoIngredientes));
		String linea = br.readLine();
		int conteo3= 27;
		while (linea != null)
		{
			String[] partes = linea.split(";");
			String nombreIngrediente= partes[0];
			int precioIngrediente = Integer.parseInt(partes[1]);
			Ingrediente elIngrediente = ingredientes.get(nombreIngrediente);
			if (elIngrediente == null)
			{
				elIngrediente = new Ingrediente(nombreIngrediente, precioIngrediente);
				ingredientes.put(nombreIngrediente, elIngrediente);
				noIngredientes.put(Integer.toString(conteo3), elIngrediente);
				list_ingredientes.add(elIngrediente);
			}
			linea = br.readLine();
			conteo3++;
			
		}
		br.close();
	}
	
	private static void cargarMenu(File archivoMenu) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(archivoMenu));
		String linea = br.readLine();
		int conteo1= 1;
		while (linea != null)
		{
			String[] partes = linea.split(";");
			String nombreProducto= partes[0];
			int precioProducto = Integer.parseInt(partes[1]);
			ProductoMenu elProducto = menu.get(nombreProducto);
			if (elProducto == null)
			{
				elProducto = new ProductoMenu(nombreProducto, precioProducto);
				menu.put(nombreProducto, elProducto);
				noProductoMenu.put(Integer.toString(conteo1), elProducto);
				list_productosMenuBase.add(elProducto);
			}
			linea = br.readLine();
			conteo1++;
		}
		br.close();
	}
	
	private static void cargarCombos(File archivoCombos) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(archivoCombos));
		String linea = br.readLine();
		int conteo2= 23;
		while (linea != null)
		{
			String[] partes = linea.split(";");
			String nombreCombo= partes[0];
			
			int descuentoCombo = Integer.parseInt(partes[1].replace("%",""));
			Combo elCombo = combos.get(nombreCombo);
			if (elCombo == null)
			{
				String nombreproducto1= partes[2];
				String nombreproducto2= partes[3];
				String nombreproducto3= partes[4];
				ProductoMenu producto1= menu.get(nombreproducto1);
				ProductoMenu producto2= menu.get(nombreproducto2);
				ProductoMenu producto3= menu.get(nombreproducto3);
				elCombo = new Combo(nombreCombo, descuentoCombo, producto1.getPrecio(),producto2.getPrecio(),producto3.getPrecio() );
				combos.put(nombreCombo, elCombo);
				noCombos.put(Integer.toString(conteo2), elCombo);
				list_combos.add(elCombo);
			}
			linea = br.readLine();
			conteo2++;
		}
		br.close();
	}
	
	
}
