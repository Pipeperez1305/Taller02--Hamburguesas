package uniandes.dpoo.taller2.modelo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Pedido {
	
	private int numeroPedidos;
	private int idPedido;
	private String nombreCliente;
	private String direccionCliente;
	private ArrayList<Producto> itemsPedido;
	private int precioNetoPedido;
	private int precioTotalPedido;
	private int precioIVAPedido;
	
	{
		this.numeroPedidos=0;
		this.idPedido=0;
		
	}
	

	
	
	public Pedido(String nombreCliente, String direccionCliente)
	{
		this.nombreCliente= nombreCliente;
		this.direccionCliente= direccionCliente;
		precioNetoPedido=0;
		precioTotalPedido=0;
		precioIVAPedido=0;
		this.idPedido++;
		this.numeroPedidos++;
		itemsPedido= new ArrayList<>();
		
	}
	
	public int getIdPedido() {
		return idPedido;
	}
	
	public void agregarProducto(Producto nuevoItem) {
		itemsPedido.add(nuevoItem);
		precioNetoPedido= precioNetoPedido+nuevoItem.getPrecio();
		precioIVAPedido= precioNetoPedido*(19/100);
		precioTotalPedido= precioNetoPedido+precioIVAPedido;
	}
	
	public void agregarIngrediente(ProductoMenu productobase,Ingrediente nuevoItem) {
		ProductoAjustado productoajustado= new ProductoAjustado (productobase);
		productoajustado.agregarIngrediente(nuevoItem);
		itemsPedido.add(productoajustado);
	}
	
	public void eliminarIngrediente(ProductoMenu productobase,Ingrediente nuevoItem) {
		ProductoAjustado productoajustado= new ProductoAjustado (productobase);
		productoajustado.agregarIngrediente(nuevoItem);
		itemsPedido.add(productoajustado);
	}

	public void agregarProductoCombo(Combo combobase,ProductoMenu nuevoItem) {
		combobase.agregaritemACombo(nuevoItem);
		itemsPedido.add(combobase);
	}
	
	
	
	private int getPrecioNetoPedido() {
		return precioNetoPedido ;
	}
	
	private int getPrecioTotalPedido() {
		return precioTotalPedido;
	}
	
	private int getPrecioIVAPedido() {
		return precioIVAPedido;
	}
	
	public String generarTextoFactura() {
		String m_factura="";
		m_factura += "RESTAURANTE DE HAMBURGUESAS\n";
		m_factura+= "------------------------------\n\n";
		m_factura += "ID pedido: "+idPedido+"\n";
		m_factura += "Nombre cliente: "+nombreCliente+"\n";
		m_factura += "Direccion cliente: "+direccionCliente+"\n";
		m_factura+= "Productos adquiridos\n------------------------------\n";
		for (Producto producto: itemsPedido) {
			m_factura += producto.generarTextoFactura()+"\n\n";
		}
		m_factura+="\n------------------------------\nPrecio neto: $"+ getPrecioNetoPedido()+"\n";
		m_factura+="IVA: $"+ getPrecioIVAPedido()+"\n";
		m_factura+="Precio Total: $"+ getPrecioTotalPedido()+"\n------------------------------\n";
		m_factura+="\n¡Gracias por su compra!";
	return m_factura;
		
	}
	
	public void guardarFactura(FileWriter archivo) throws IOException {
		String factura = this.generarTextoFactura();
		archivo.write(factura);
		archivo.close();
	
		
		
	}
}
