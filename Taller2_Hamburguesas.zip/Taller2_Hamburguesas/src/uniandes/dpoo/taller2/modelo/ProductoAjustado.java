package uniandes.dpoo.taller2.modelo;

import java.util.ArrayList;

public class ProductoAjustado implements Producto {
    
	private String nombre;
	private int precioBase;
	private String agregados;
	private String eliminados;
	
	
	public ProductoAjustado(ProductoMenu base)
	{
		this.nombre= base.getNombre();
		this.precioBase= base.getPrecio();
		this.agregados="";
		this.eliminados="";
	}
	
	public void agregarIngrediente(Ingrediente ingrediente) {
		this.agregados= agregados + ingrediente.getNombre() +" ,";
		this.precioBase= precioBase+ingrediente.getcostoAdicional();
		
	}
	
	public void eliminarIngrediente(Ingrediente ingrediente) {
		this.eliminados= eliminados + ingrediente.getNombre() +" ,";
		
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getAgregados() {
		return agregados;
		
	}
	
	public String getEliminados() {
		return eliminados;
	}
	
	public int getPrecio() {
		return precioBase;
	}
	
	public String generarTextoFactura() {
		String productoAjustado="";
		productoAjustado+="+ "+ nombre+" ----- $"+Integer.toString(precioBase)+"\n";
		if (agregados != "") {
			productoAjustado+="(Con adicion de "+agregados+")\n";	
		}
		if (eliminados != "") {
			productoAjustado+="(Sin "+eliminados+")\n";
		}
		return productoAjustado;
		
	}
}
