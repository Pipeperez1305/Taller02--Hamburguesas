package uniandes.dpoo.taller2.consola;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import uniandes.dpoo.taller2.modelo.Combo;
import uniandes.dpoo.taller2.modelo.Ingrediente;
import uniandes.dpoo.taller2.modelo.Pedido;
import uniandes.dpoo.taller2.modelo.ProductoMenu;
import uniandes.dpoo.taller2.modelo.Restaurante;

public class Aplicacion {
	 
	
	public void ejecutarAplicacion() throws IOException
	{
		
		System.out.println("APLICACION HAMBURGUESAS");

		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenu();
				int opcion_seleccionada = Integer.parseInt(input("Por favor seleccione una opción"));
				if (opcion_seleccionada == 1)
					ejecutarMostrarMenu();
				else if (opcion_seleccionada == 2)
					ejecutarIniciarNuevoPedido();
				else if (opcion_seleccionada == 3)
					ejecutarAgregarElementoPedido();
				else if (opcion_seleccionada == 4)
					ejecutarCerrarPedidoGuardarFactura();
				else if (opcion_seleccionada == 5)
					ejecutarCosultarPedidoConId();
				else if (opcion_seleccionada == 6)
				{
					System.out.println("Saliendo de la aplicación ...");
					continuar = false;
				}
				
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los números de las opciones.");
			}
		}
	}

	public String input(String mensaje)
	{
		try
		{
			System.out.print(mensaje + ": ");
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			return reader.readLine();
		}
		catch (IOException e)
		{
			System.out.println("Error leyendo de la consola");
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Muestra al usuario el menú con las opciones para que escoja la siguiente
	 * acción que quiere ejecutar.
	 */
	public void mostrarMenu()
	{
		System.out.println("\nOpciones de la aplicación\n");
		System.out.println("1. Mostrar Menú");
		System.out.println("2. Inicia un nuevo pedido");
		System.out.println("3. Agregar un elemento a un pedido");
		System.out.println("4. Cerrar un pedido y guardar la factura");
		System.out.println("5. Consultar la información de un pedido dado su id");
		System.out.println("6. Salir de la aplicación\n");
	}
	/**
	 * Le muestra el usuario el porcentaje de atletas que son medallistas
	 * @throws IOException 
	 */
	private void ejecutarMostrarMenu() throws IOException
	{
		
		System.out.println("MENU RESTAURANTE HAMBURGUESA");
		System.out.println("                ");
		
		System.out.println("1.Productos Base");
		System.out.println("                ");
		ArrayList<ProductoMenu> menuBase= Restaurante.getMenuBase();
		int conteo1=1;
		for (ProductoMenu producto : menuBase)
		{
			System.out.println(Integer.toString(conteo1)+". " +producto.getNombre()+ " ---------------- "+ "$"+Integer.toString(producto.getPrecio()));
			conteo1= conteo1+1;
		}
		System.out.println("                ");
		System.out.println("2. Combos");
		System.out.println("                ");
		ArrayList<Combo> combos= Restaurante.getCombos();
		int conteo2=conteo1;
		for (Combo combo : combos)
		{
			System.out.println(Integer.toString(conteo2)+". " +combo.getNombre()+ " ---------------- "+ "$"+Integer.toString(combo.getPrecio()));
			conteo2= conteo2+1;
		
		}
		System.out.println("                ");
		System.out.println("3.Adiciones (Ingredientes)");
		System.out.println("                ");
		ArrayList<Ingrediente> ingredientes= Restaurante.getIngredientes();
		int conteo3=conteo2;
		for (Ingrediente ingrediente : ingredientes)
		{
			System.out.println(Integer.toString(conteo3)+". " + ingrediente.getNombre()+ " ---------------- "+ "$"+Integer.toString(ingrediente.getcostoAdicional()));
			conteo3= conteo3+1;
		
		}
		System.out.println("                ");
	}
	/**
	 * Le pide el usuario el nombre de un país y un género, y luego le muestra la
	 * información de los medallistas de ese género que han representado a ese país.
	 */
	private void ejecutarIniciarNuevoPedido()
	{
		System.out.println("\n" + "Nuevo Pedido" + "\n");

		String nombreCliente = input("Por favor ingrese el nombre del cliente ");
		String direccionCliente = input("Por favor ingrese la direccion del cliente ");
		Restaurante.iniciarPedido(nombreCliente, direccionCliente);
		}


	/**
	 * Le informa al usuario si hay un atleta todoterreno y la cantidad de deportes
	 * diferentes en los que ha participado
	 */
	private void ejecutarAgregarElementoPedido()
	
	{
		boolean agregando_elemento = true;
		System.out.println("Agregar elementos al pedido");
		System.out.println("                           ");
		while (agregando_elemento) {
		int item_add= Integer.parseInt(input("Por favor seleccione una de las opciones del Menú presentado (Combos y/o Productos base) "));
		Restaurante.agregarProducto(item_add);
		int seguir= Integer.parseInt(input("Quiere seguir agregando elementos? (1-Si, 0-No) "));
		if (seguir==1) {
			agregando_elemento= true;
		}
		else {
			agregando_elemento= false;
		}
		}
		
		
		int agregar_ingrediente= Integer.parseInt(input("Quiere agregar un producto con adición de ingredientes? (1-Si, 0-No) "));
		System.out.println("                           ");
		if (agregar_ingrediente == 1){
			
			boolean agregando_ingrediente = true;
			
			while (agregando_ingrediente) {
			
			int agregar= Integer.parseInt(input("Quiere agregar ingredientes? (1-Si, 0-No) "));
			System.out.println("                           ");
			if (agregar==1) {
				int producto= Integer.parseInt(input("De los productos base del menu, escriba el número al que quiere agregar ingredientes "));
				int ingrediente= Integer.parseInt(input("De los Ingredientes del menu, escriba el número del que quiere agregar al producto seleccionado "));
				Restaurante.agregarIngredientes(producto, ingrediente);
			}
			
			int eliminar= Integer.parseInt(input("Quiere eliminar ingredientes? (1-Si, 0-No) "));
			System.out.println("                           ");
			if (eliminar==1) {
				int producto_base= Integer.parseInt(input("De los productos base del menu, escriba el número al que quiere eliminar ingredientes "));
				int elim_ingrediente= Integer.parseInt(input("De los Ingredientes del menu, escriba el número del que quiere eliminar al producto seleccionado "));
				Restaurante.eliminarIngredientes(producto_base, elim_ingrediente);
			}
			int seguir_ing= Integer.parseInt(input("Quiere seguir agregando productos con adición o no de ingredientes? (1-Si, 0-No)  "));
			if (seguir_ing==1) {
				agregando_ingrediente= true;
			}
			else {
				agregando_ingrediente= false;
			}
			}
		}
		
		int agregar_producto= Integer.parseInt(input("Quiere agregar un combo con adición de productos base? (1-Si, 0-No) "));
		System.out.println("                           ");
		if (agregar_producto == 1){
			
			boolean agregando_combo = true;
			
			while (agregando_combo) {
			
			int combo= Integer.parseInt(input("De los combos del menú, escriba el número al que quiere agregar productos "));
			int producto_base= Integer.parseInt(input("De los Productos base del menu, escriba el número del que quiere agregar al combo seleccionado "));
			Restaurante.agregarProductoCombo(combo, producto_base);
			int seguir_cmb= Integer.parseInt(input("Quiere seguir agregando combos con adiciones al pedido? (1-Si, 0-No) "));
			if (seguir_cmb==1) {
				agregando_combo= true;
			}
			else {
				agregando_combo= false;
			}
			}
		}
		}
		
			
		
	

	/**
	 * Le pide al usuario el nombre de un evento y luego le informa cuál es el mejor
	 * país en ese evento.
	 * @throws IOException 
	 */
	private void ejecutarCerrarPedidoGuardarFactura() throws IOException
	{
		Restaurante.cerrarYGuardarPedido();
		System.out.println("Se guardó exitosamente el Pedido");
	}

	/**
	 * Muestra cuáles han sido los atletas (o el atleta) que más medallas ha ganado.
	 */
	private void ejecutarCosultarPedidoConId()
	{
		String IdPedido= input("Por favor ingrese el Id del pedido a consultar ");
		String facturaPedido= Restaurante.consultarPedidoPorId(IdPedido);
		System.out.println(facturaPedido);
		
	}
	
	public static void main(String[] args) throws IOException
	{
		File fcombos = new File("data/combos.txt");
		File fingredientes = new File("data/ingredientes.txt");
		File fmenu = new File("data/menu.txt");
		try {
			Restaurante.cargarInformacionRestaurante(fingredientes,fmenu, fcombos);
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Aplicacion consola = new Aplicacion();
		consola.ejecutarAplicacion();
	}
}
